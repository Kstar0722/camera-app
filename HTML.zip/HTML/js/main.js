
//-- Navigation --//
function process(){
    $(".width").html($(window).width());
    if( $(window).width() > 1024){
        $("body").removeClass("mobile").addClass("desktop");
    }else{
        $("body").removeClass("desktop").addClass("mobile");
    }
}

jQuery(document).ready(function($) {
    //-- Navigation --//
    process();
    $(".navbar-toggle").on("click", function () {
        if(!$(this).hasClass("open")){
            $(this).addClass("open");
            $('#Side').addClass('side-open');
            $('body').addClass('backdrop');
        }
        else {
            $(this).removeClass('open');
            $('#Side').removeClass('side-open');
            $('body').removeClass('backdrop');
        }
    });

    $("#time-pick").flatpickr({
        enableTime: true,
        dateFormat: "Y-m-d | h:i:S:K",
        time_24hr: false,
    });

    //-- Form search --//
    $('.search-mobile').on('click', function(event) {
        event.preventDefault();
        if (!$(this).siblings('.form-search').hasClass('open')) {
            $(this).siblings('.form-search').addClass('open');
        }
        else {
            $(this).siblings('.form-search').removeClass('open');   
        }
    });
    $('.close-search').on('click', function(event) {
        $(this).parents('.form-search').removeClass('open');
    });
    $('.advance-search').on('click', function(event) {
        event.preventDefault();
        /* Act on the event */
        if (!$(this).parents('.form-search').siblings('.block-advance').hasClass('open')) {
            $(this).parents('.form-search').siblings('.block-advance').addClass('open');
            $(this).text('Hide advance search');
        }
        else {
            $(this).parents('.form-search').siblings('.block-advance').removeClass('open')   
            $(this).text('Advance search');
        }
    });

    //-- nav tabs --//
    $('.main-content .nav-tabs li a').on('click', function(event) {
        event.preventDefault();
        /* Act on the event */
        if (!$(this).parents('.nav-tabs').hasClass('nav-tabs-show')) {
            $(this).parents('.nav-tabs').addClass('nav-tabs-show');
        }
        else {
            $(this).parents('.nav-tabs').removeClass('nav-tabs-show');
        }
        
    });

    //-- Slide pictures --//
    $('.slide-item').each(function() {
        var imgSrc = $(this).children('p').find('img').attr('src');
        $(this).css('background', 'url("' + imgSrc + '")');
        $(this).children('p').find('img').hide();
        $(this).css('background-position', 'initial');
    });

    $('.modal').on('shown.bs.modal', function (e) {
        if($('.slide-pictures').length > 0){
            $(".slide-pictures").slick({
                autoplay: false,
                autoplaySpeed: 1500,
                infinite: true,
                slidesToShow: 1,
                arrows: true
            });
        }
        $('.form-comment textarea').on('focus', function(event) {
            event.preventDefault();
            $(this).parent().addClass('write-comment');
        }).on('blur', function(event) {
            $(this).parent().removeClass('write-comment');
        });
    });

    if ($('[data-toggle="tooltip"]').length > 0) {
        $('[data-toggle="tooltip"]').tooltip();
    }

    //-- Tab event --//
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        
    });

    //-- Target click --//
    $(document).on('click touchstart', function (event) {
        //-- Nav --//
        if($(event.target).closest('.navbar-toggle, #Side').length === 0){
            $('.navbar-toggle').removeClass('open');
            $('#Side').removeClass('side-open');
            $('body').removeClass('backdrop');
        }
        if($(event.target).closest('.search-mobile, .form-search').length === 0){
            $('.form-search').removeClass('open');
        }

        //-- Search form --//
        if($(event.target).closest('.block-search').length === 0){
            if ($('.search-form').hasClass('search-show')) {
                $('.search-form').removeClass('search-show');
                $('.search-form input[type="text"]').val('');
            }
        }

        //-- Nav tabs --//
        if($(event.target).closest('.nav-tabs').length === 0){
            if ($('.nav-tabs').hasClass('nav-tabs-show')) {
                $('.nav-tabs').removeClass('nav-tabs-show');
            }
        }
    });
});

$(window).load(function() {
    if ($('.col-list .col-item .description').length > 0) {
        $('.col-list .col-item .description').matchHeight();
    }
    if ($('.box-list .box-item').length > 0) {
        $('.box-list .box-item').matchHeight();
    }
});

$(window).resize(function(){
    //-- Navigation --//
    process();

    if ($('body').hasClass('backdrop')) {
        $('body').removeClass('backdrop');
    }
    if($('#Side').hasClass('side-open')){
        $('#Side').removeClass('side-open');
    }
    if($('.navbar-toggle').hasClass('open')){
        $('.navbar-toggle').removeClass('open');
    }
    if($('.form-search').hasClass('open')){
        $('.form-search').removeClass('open');
    }
    if($('.nav-tabs').hasClass('nav-tabs-show')){
        $('.nav-tabs').removeClass('nav-tabs-show');
    }

    //-- Equal height --//
    if ($('.col-list .col-item .description').length > 0) {
        $('.col-list .col-item .description').matchHeight();
    }
    if ($('.box-list .box-item').length > 0) {
        $('.box-list .box-item').matchHeight();
    }

});