
//-- Navigation --//
function process(){
    $(".width").html($(window).width());
    if( $(window).width() > 1024){
        $("body").removeClass("mobile").addClass("desktop");
    }else{
        $("body").removeClass("desktop").addClass("mobile");
    }
}

jQuery(document).ready(function($) {
    //-- Navigation --//
    process();
    $(".navbar-toggle").on("click", function () {
        if(!$(this).hasClass("open")){
            $(this).addClass("open");
            $('#Side').addClass('side-open');
            $('body').addClass('backdrop');
        }
        else {
            $(this).removeClass('open');
            $('#Side').removeClass('side-open');
            $('body').removeClass('backdrop');
        }
    });

    $("#time-pick").flatpickr({
        enableTime: true,
        dateFormat: "Y-m-d | h:i:S:K",
        time_24hr: false,
    });

    //-- Form search --//
    $('.search-mobile').on('click', function(event) {
        event.preventDefault();
        if (!$(this).siblings('.form-search').hasClass('open')) {
            $(this).siblings('.form-search').addClass('open');
        }
        else {
            $(this).siblings('.form-search').removeClass('open');   
        }
    });
    $('.close-search').on('click', function(event) {
        $(this).parents('.form-search').removeClass('open');
    });

    // nav tabs
    $('.main-content .nav-tabs li a').on('click', function(event) {
        event.preventDefault();
        /* Act on the event */
        if (!$(this).parents('.nav-tabs').hasClass('nav-tabs-show')) {
            $(this).parents('.nav-tabs').addClass('nav-tabs-show');
        }
        else {
            $(this).parents('.nav-tabs').removeClass('nav-tabs-show');
        }
        
    });

    //-- Target click --//
    $(document).on('click touchstart', function (event) {
        //-- Nav --//
        if($(event.target).closest('.navbar-toggle, #Side').length === 0){
            $('.navbar-toggle').removeClass('open');
            $('#Side').removeClass('side-open');
            $('body').removeClass('backdrop');
        }
        if($(event.target).closest('.search-mobile, .form-search').length === 0){
            $('.form-search').removeClass('open');
        }

        //-- Search form --//
        if($(event.target).closest('.block-search').length === 0){
            if ($('.search-form').hasClass('search-show')) {
                $('.search-form').removeClass('search-show');
                $('.search-form input[type="text"]').val('');
            }
        }

        //-- Nav tabs --//
        if($(event.target).closest('.nav-tabs').length === 0){
            if ($('.nav-tabs').hasClass('nav-tabs-show')) {
                $('.nav-tabs').removeClass('nav-tabs-show');
            }
        }
    });
});

$(window).resize(function(){
    //-- Navigation --//
    process();

    if ($('body').hasClass('backdrop')) {
        $('body').removeClass('backdrop');
    }
    if($('#Side').hasClass('side-open')){
        $('#Side').removeClass('side-open');
    }
    if($('.navbar-toggle').hasClass('open')){
        $('.navbar-toggle').removeClass('open');
    }
    if($('.form-search').hasClass('open')){
        $('.form-search').removeClass('open');
    }
    if($('.nav-tabs').hasClass('nav-tabs-show')){
        $('.nav-tabs').removeClass('nav-tabs-show');
    }

});